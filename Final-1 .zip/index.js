//////////////////
const express = require('express');
const bodyParser = require('body-parser');

const app = express();


//form code decode midware
app.use(express.urlencoded({
  extended: true
}));

// create application/json parser
const jsonParser = bodyParser.json()

//set static folder
app.use(express.static('resources'));

app.get('/', (req, res) => {
 res.sendFile(__dirname +'/resources/html/index.html');
});

const fs = require("fs");

app.post('/save',jsonParser, (req, res) => 
{
  //let name = JSON.stringify(req.body.name).trim();
  let name = req.body.name;
  let password = req.body.password;
  console.log("Input user name =" + name);
  let myJson = {error:false, data:""}; 

  let oldUser = false;
  let userPosition;

  let newJson;

  fs.readFile('./secure/username.json', "utf-8", (err, jsonString) => 
  {
    if (err) 
    {
      console.log("Error reading file from disk:", err);
      return;
    }

    try {

      newJson = JSON.parse(jsonString);
      console.log("Old JSON is:", jsonString);
      console.log("Old JSON obj is ", newJson[0]);

      for (i = 0; i < newJson.length; i++) 
      {
        if (newJson[i].username == name) 
        {
          oldUser = true;
          userPosition = i;
          break;
        }
      }
    } catch (err) 
    {
      console.log("Error parsing JSON string:", err);
    }

    if (oldUser) 
    {
      if (newJson[userPosition].password == password) 
      {
        return res.json(myJson);
      }
      else {
        myJson = { error: true, data: "" };
        return res.json(myJson);
      }
    }
    else {
      myJson = { error: true, data: "" };
      return res.json(myJson);
    }
  });
});
//sign up
app.post('/signup', jsonParser, (req, res) => {
  let name = req.body.name;
  let password = req.body.password;
  let myJson = { error: false, data: "" };

  let oldUser = false;

  let newJson;

  fs.readFile('./secure/username.json', "utf-8", (err, jsonString) => {
    if (err) {
      console.log("Error reading file from disk:", err);
      return;
    }
    try {

      newJson = JSON.parse(jsonString);

      for (i = 0; i < newJson.length; i++) {
        if (newJson[i].username == name) {
          oldUser = true;
          break;
        }
      }

      if (newJson == null) {
        console.log("JSON file is empty");
        let newUser = [{ username: name , password: password}];

        fs.writeFile('./secure/username.json', JSON.stringify(newUser), err => {
          if (err) {
            console.log('Error writing file', err);
            myJson = {error: true, data: ""};
            return res.json(myJson);
          } else {
            console.log('Successfully wrote empty file');
            return res.json(myJson);
          }
        })
      } else if(!oldUser){
        let newUser = { username: name, password: password};
        newJson.push(newUser);
        fs.writeFile('./secure/username.json', JSON.stringify(newJson), err => {
          if (err) {
            console.log('Error writing file', err);
            myJson = {error: true, data: ""};
            return res.json(myJson);
          } else {
            console.log('Successfully wrote file');
            return res.json(myJson);
          }
        })
      }else if(oldUser){
        myJson = {error: true, data: ""};
        return res.json(myJson);
      }
    } catch (err) {
      console.log("Error parsing JSON string:", err);
    }
    
  });
});

app.get('/signup', (req, res) => {
  res.sendFile(__dirname + '/resources/html/register.html');
});

///// game page
app.get('/game', (req, res) => {
   res.sendFile(__dirname +'/html/gameplay.html');
});


// get error page when the link was wrong.
app.get('*', function(req, res)
{
  res.status(404).sendFile(__dirname + '/resources/html/error404.html')
});

app.listen(3000, () => {
  console.log('server started');
});



