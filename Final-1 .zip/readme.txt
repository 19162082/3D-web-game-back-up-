Reference List:

The source code is referenced from: 
[online] Available at: <https://moodle.bcu.ac.uk/course/view.php?id=84268>. [Accessed 1 October 2021].

The background music is referenced from:
[online] Available at: <https://www.chosic.com/download-audio/24995/>. [Accessed 20 December 2021].

The character model is referenced from: 
[online] Available at: <https://sketchfab.com/3d-models/vintage-toy-airplane-2-b40dc984692746b3a5132adffc3a14ad>. [Accessed 10 November 2021].

The coin model is referenced from:
[online] Available at: <https://sketchfab.com/3d-models/stylized-coin-8cd6f95c44994ed5944a42892d0ffc10>. [Accessed 25 December 2021].

The skybox images is referenced from :
[online] Available at: <https://opengameart.org/content/cloudy-skyboxes>. [Accessed 23 November 2021].

The collecting coin sound is referenced from:
[online] Available at: <https://orangefreesounds.com/mario-coin-sound/>. [Accessed 28 December 2021].

The Code Snippets is referenced from:
[online] Threejs.org. Available at: <https://threejs.org/docs/> [Accessed 17 November 2021].

My project link in Repl.it is:
https://replit.com/@NgocHuyNguyen/Final-1#index.js
