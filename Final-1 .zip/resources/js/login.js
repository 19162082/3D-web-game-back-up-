const postUser =()=>{

  let username = document.getElementById("uname").value;
  let password = document.getElementById("pwd").value;
  let formData = {name: username, password: password};

  let postData = JSON.stringify(formData);

    let xhr = new XMLHttpRequest();

    xhr.open("POST", "/save", true);
    xhr.setRequestHeader('Content-type', 'application/json')
    xhr.send(postData);

    xhr.onload =()=>{
      let result = xhr.response;
      console.log("Get response from express:" + result);
      let resultObj = JSON.parse(result);
      
      if(resultObj.error){
        document.querySelector("#result").innerHTML = "Wrong username or password, try again?."
      }else{
        //alert("correct user!");
        location.replace("../game")
      }
    }
}

const form = document.querySelector("#loginbtn");
form.addEventListener('click', postUser);