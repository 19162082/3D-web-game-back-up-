let username = document.getElementById("uname");
let password = document.getElementById("pwd");
let score = document.getElementById("score");
let submit = document.getElementById("btn");
score.value = 0;

const postUser =()=>{

  let formData = {name: username.value, password: password.value, score: score.value};

  let postData = JSON.stringify(formData);

    let xhr = new XMLHttpRequest();

    xhr.open("POST", "/signup", true);
    xhr.setRequestHeader('Content-type', 'application/json')
    xhr.send(postData);

    xhr.onload =()=>{
      let result = xhr.response;
      console.log("Get response from express:" + result);
      let resultObj = JSON.parse(result);
      
      if(resultObj.error){
        document.querySelector("#result").innerHTML = "Username or password already exist, please try again."
      }else{
        alert("User Saved!");
        location.replace("../")
      }
    }
}

const form = document.querySelector("#btn");
form.addEventListener('click', postUser);