
import * as THREE from 'https://unpkg.com/three@0.127.0/build/three.module.js';
import { OrbitControls } from 'https://unpkg.com/three@0.127.0/examples/jsm/controls/OrbitControls.js';
import { GLTFLoader } from 'https://unpkg.com/three@0.127.0/examples/jsm/loaders/GLTFLoader.js';

import Stats from 'https://unpkg.com/three@0.127.0/examples/jsm/libs/stats.module.js';


let scene, renderer;
let camera;
let mesh;
let stats;
let coin;
let score = 0;

const init=()=> 
{
    
    //add scene
    scene = new THREE.Scene(); 
    
    //add camera
    camera = new THREE.PerspectiveCamera( 75, window.innerWidth/window.innerHeight, 0.1, 10000 ); 
    
      
    //add renderer
    renderer = new THREE.WebGLRenderer(); 
    renderer.setSize( window.innerWidth, window.innerHeight ); 
    document.body.appendChild( renderer.domElement ); 

    
    //add stats
    const addStats=()=>
    {
      stats = new Stats();
      document.body.appendChild(stats.dom);
    }
    addStats();
    
    


    //add background color
    renderer.setClearColor(0x6c97ce, 1); 
    renderer.gammaOutput = true;
    


    //add light
    const light = new THREE.DirectionalLight("0xffffff", 1);
    const ambient = new THREE.AmbientLight("0xffffff");
    light.position.set( 0, 0, 100 ).normalize();
    ambient.position.set( 0, 0, 50 ).normalize();
    scene.add(light);
    scene.add(ambient);


    //add the listener
    const listener = new THREE.AudioListener();
    const sound = new THREE.Audio( listener );

    //collecting coin sound
    const coinSound = new THREE.Audio( listener );
    camera.add( listener )



    //add music into game 
     
     const audioLoader = new THREE.AudioLoader();audioLoader.load( '../Audio/Song.wav', function( buffer ) {
        sound.setBuffer( buffer );
        sound.setLoop( true );
        sound.setVolume( 1 );
        sound.play();
        });


    //all variables for player
    var speed = -0.17;
    var wPressed = false;
    var aPressed = false;
    var sPressed = false;
    var dPressed = false; 


    //create cube for camera to follow
    const camera_cube_geometry = new THREE.BoxGeometry(0.02, 0.02, 0.02);
		const camera_cube_material = new THREE.MeshLambertMaterial( { color: 0xff3333, emissive:0xffcccc,specular:0x61c975, shininess:32 } );
		const camera_cube = new THREE.Mesh( camera_cube_geometry, camera_cube_material );
		scene.add( camera_cube );
    camera_cube.position.x += 0;
    camera_cube.position.y += 1;
    camera_cube.position.z += 0;
    camera_cube.add (camera);
      

    //// add player
    const player = new THREE.Mesh(mesh);
    
    player.position.x = 0;
    player.position.y = 0;
    player.position.z = 0;
    scene.add( player );
   
 
    /// set camera's position
    camera.position.z = 5;
    camera.position.y = 5;
    camera.rotation.x = 0;

    ////// loading GLTF plane model
  
    const loader = new GLTFLoader().setPath( '../models/' );

    loader.load
    ( 
        'scene.gltf',
         ( gltf )=> 
         {
            mesh = gltf.scene;
            mesh.scale.set( 0.001, 0.001, 0.001 );
            player.add( mesh );
            mesh.rotation.y= Math.PI ; 
            mesh.position.set(0,1,0)
                                  
        }, 
    );


    ////loading GLB coin model

    loader.load
    ( 
        'coin.glb',
         ( gltf )=> 
         {
            coin = gltf.scene;
            coin.scale.set( 1.25,1.25,1.25 );
            scene.add(coin);
            
            coin.position.x = 0;
            coin.position.y = 0;
            coin.position.z = -20;
            
                                             
        }, 
    );

     

    //creating text for the score displayed on the scene.
     let text_score = document.createElement('div_1');
     text_score.style.position = 'absolute';
     text_score.style.width = 50 + "%";
     text_score.style.height = 50;
     text_score.style.textAlign = "left";
     text_score.style.fontWeight = "bolder";
     text_score.style.fontSize = 40 + "px";
     text_score.style.color = 'red';
     text_score.innerHTML = "Score:" + score;
     text_score.style.top = 100 + 'px';
     text_score.style.left = 70 + 'px';
     document.body.appendChild(text_score);

    
    //// adding obstacle
    const obstacle= new THREE.BoxGeometry(1,1,1);

    for (let i =0; i < 2000; i++)
    {
      const obstacle_spawn=new THREE.Mesh(obstacle, new THREE.MeshLambertMaterial({color:Math.random()*0xffffff}));

      obstacle_spawn.position.x= Math.random() * 40-20;
      obstacle_spawn.position.y= Math.random() * 4-2;
      obstacle_spawn.position.z= Math.random() * 10000-5000;

      scene.add(obstacle_spawn);

    }
  
    // player's control

    document.addEventListener("keydown", onDocumentKeyDown, false);
    document.addEventListener("keyup", onDocumentKeyUp, false);
    function onDocumentKeyDown(event) 
    {
      var keyCode = event.which;
      if (keyCode == 87) 
      {
        wPressed = true;
      } 
      else if (keyCode == 83) 
      {
        sPressed = true;
      } 
      else if (keyCode == 65) 
      {
        aPressed = true;
      } 
      else if (keyCode == 68) 
      {
        dPressed = true;
      } 
    };


    function onDocumentKeyUp(event)
    {
     var keyCode = event.which;

     if (keyCode == 87) 
     {
      wPressed = false;
     } 
     else if (keyCode == 83) 
     {
      sPressed = false;
     } 
     else if (keyCode == 65) 
     {
      aPressed = false;
     } 
     else if (keyCode == 68)
     {
      dPressed = false;
     } 
    };
    
    /////create a skybox cube
      const loader_skgbox = new THREE.CubeTextureLoader();
      const texture = loader_skgbox .load(['/pattern/bluecloud_rt.jpg', 
'/pattern/bluecloud_lf.jpg','/pattern/bluecloud_up.jpg','/pattern/bluecloud_dn.jpg','/pattern/bluecloud_bk.jpg','/pattern/bluecloud_ft.jpg',]);
        scene.background = texture;


    ////////////animation
    const animate = function () 
    {
      requestAnimationFrame( animate );
			renderer.render( scene, camera );
      
      /////// player control anim

        if (wPressed == true) 
        {
          player.position.y += 0.03;
          player.rotation.y = 0.15;
          player.rotation.x = -0.1;
        }
         else
         {
          player.rotation.x = 0.05;
        }

        if (sPressed == true) 
        {
          player.position.y += -0.03;
                     
        }
        
        if (aPressed == true) 
        {
          player.position.x += -0.03;
          player.rotation.y = 0.15;
          player.rotation.z = 0.15;
        }
        else
        {
          player.rotation.y = 0;
          player.rotation.z = 0;
          camera_cube.position.y = -3;
        }

        if (dPressed == true) 
        {
          player.position.x += 0.03;
          player.rotation.y = -0.15;
          player.rotation.z = -0.15;
        }


        if (player.position.y >= 2.5) 
        {
          player.position.y = 2.5;
        }
        if (player.position.y <= -2.5) 
        {
          player.position.y = -2.5;
        }


        if(player.position.x >= 6) 
        {
          player.position.x = 6;
        }
        if(player.position.x <= -6) 
        {
          player.position.x = -6;
        }

        player.rotation.x += 0;
				player.rotation.y += 0;
        player.rotation.z += 0;
        player.position.z += speed;

        camera_cube.rotation.x += 0;
        camera_cube.rotation.z += 0;
        camera_cube.position.z += speed;
       
      
      /////update the score.
      if(Math.abs(coin.position.z - player.position.z) < 1)
      {
       if(Math.abs(coin.position.x - player.position.x) < 1)
       {
        audioLoader.load( '../Audio/Coin_sound.wav', function( buffer ) 
        {
         coinSound.setBuffer( buffer );
         coinSound.setLoop( false );
         coinSound.setVolume( 0.25 );
         coinSound.play();
        });
         score += 1;

         coin.position.z += -40;
         coin.position.x= Math.random() * 10-5;
         coin.position.y= Math.random() * 2-1;
       }
      
      ///// reset coins
       if (coin.position.z > camera_cube.position.z)
       {
        coin.position.z += -40;
       }
      }
      
      text_score.innerHTML = "Score: " + score;

      /////// coin animation
      coin.rotation.y += 0.20;         

      // stats
      stats.update();
      
      
		};

    animate();
  

  // OrbitControl
  const controls = new OrbitControls(camera, renderer.domElement);
       
    controls.update();
            
}
    

   window.addEventListener('DOMContentLoaded', init);
     
   function onWindowResize()
   {
        camera.aspect = window.innerWidth / window.innerHeight;
        camera.updateProjectionMatrix();
        renderer.setSize( window.innerWidth, window.innerHeight );
   }
  window.addEventListener( 'resize', onWindowResize );









